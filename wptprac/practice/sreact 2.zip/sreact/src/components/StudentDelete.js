import React,{useState} from'react'
import Studentservice from '../service/Studentservice'
const StudentDelete=()=>{
    let [form,setform]=useState({studid:""})
    let del=()=>{
        Studentservice.deletebyid(form.studid)
        setform({studid:""})


    }
    return(
        <div>
            Student ID To Delete:<br/>
            <input type='text' id='id' name='id' value={form.studid}
            onChange={(event)=>{setform({...form,studid:event.target.value})

            }} /><br/>
               <button type="button" onClick={del}>Delete </button>
            

        </div>
    )

}
export default StudentDelete;